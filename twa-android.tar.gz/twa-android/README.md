# Gruzli TWA — Android APK

TWA (Trusted Web Activity) открывает `https://gruzli.lovable.app` в Chrome на весь экран без адресной строки — как настоящее нативное приложение.

---

## Способ 1: GitHub Actions (самый простой — бесплатно, без установок)

1. **Создай репозиторий на GitHub** и загрузи туда папку `twa-android` как корень репо
2. Зайди в `Actions` → увидишь workflow `Build Android APK`
3. Нажми `Run workflow` → через ~3 минуты APK готов
4. Скачай APK: `Actions → последний запуск → Artifacts → gruzli-debug-apk`

Файл workflow уже включён в проект: `.github/workflows/build-apk.yml`

---

## Способ 2: Android Studio (локально)

### Требования
- [Android Studio](https://developer.android.com/studio) Hedgehog или новее
- JDK 17+

### Шаги

1. Открыть: `File → Open → папка twa-android`
2. Подождать `Sync Project with Gradle Files`
3. `Build → Build Bundle(s) / APK(s) → Build APK(s)`
4. APK: `app/build/outputs/apk/debug/app-debug.apk`

---

## Убрать адресную строку Chrome (для финального APK)

Без этого Chrome показывает адресную строку. Нужно:

### 1. Получить SHA-256 отпечаток подписи

```bash
keytool -list -v -keystore my-release-key.jks -alias my-key-alias
```
Скопировать строку `SHA256: AA:BB:CC:...` (без пробелов, через двоеточие).

### 2. Обновить fingerprint

В `app/src/main/res/values/strings.xml` заменить `YOUR_SHA256_CERT_FINGERPRINT`.

### 3. Разместить assetlinks.json на сайте

Файл `assetlinks.json` (с заменённым fingerprint) разместить по адресу:
```
https://gruzli.lovable.app/.well-known/assetlinks.json
```
Через настройки Lovable или подключив свой домен.

---

## Push-уведомления (Progressier)

TWA использует реальный Chrome — Progressier работает «из коробки», никаких дополнительных настроек не нужно.

---

## Структура проекта

```
twa-android/
├── .github/workflows/
│   └── build-apk.yml           ← GitHub Actions: собирает APK автоматически
├── app/
│   ├── build.gradle            ← зависимости Android
│   └── src/main/
│       ├── AndroidManifest.xml ← URL, deep links, TWA конфиг
│       └── res/
│           ├── values/strings.xml  ← URL и assetlinks fingerprint
│           ├── values/colors.xml   ← цвета splash screen
│           └── drawable/           ← иконка
├── assetlinks.json             ← разместить на сайте (см. выше)
├── build.gradle
└── settings.gradle
```
